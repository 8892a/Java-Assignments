public class Main {
    public static void main(String[] args) {
        Singers singer1 = new Singers();

        System.out.println("Original Values");
        System.out.println("|Name:" + singer1.getname() + "|Address:" + singer1.getaddress() + "|Birthday:" + singer1.getbirthdate() + "|ID: " + singer1.getid() + "|Albums Released: " + singer1.getalbums()+"|");

        System.out.println("Updated Values");
        singer1.Setname("Ariana Grande");
        singer1.Setaddress("402 Ridgebury Drive");
        singer1.Setalbums(43);
        singer1.Setid(493824);
        singer1.Setbirthdate("04-12-94");

        System.out.println("|Name:" + singer1.getname() + "|Address:" + singer1.getaddress() + "|Birthday:" + singer1.getbirthdate() + "|ID: " + singer1.getid() + "|Albums Released: " + singer1.getalbums()+"|");
    }
}


